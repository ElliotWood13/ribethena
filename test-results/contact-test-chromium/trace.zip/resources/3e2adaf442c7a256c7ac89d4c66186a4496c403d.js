(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_be64e9a3._.js",
  "static/chunks/app_components_JuiceCup_module_f68b49e9.css"
],
    source: "dynamic"
});
